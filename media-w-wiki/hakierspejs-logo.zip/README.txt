(English Translation)

# Polish

Autorem tego logo jest **Dominik Pietrzak**. W celu ułatwienia używania
tego logo, autor wyraża zgodę na jego publikację na zasadach opisanych
w licencji Creative Commons Zero, opisanej tutaj:

https://creativecommons.org/publicdomain/zero/1.0/deed.pl

Pełen tekst licencji można znaleźć w pliku LICENSE.pl.txt oraz tutaj:

https://creativecommons.org/publicdomain/zero/1.0/legalcode.pl

# English

The author of this logo is Dominik Pietrzak. In order to simplify the
usage of the logo, the author allows its use within the scope of
Creative Commons Zero license, which is described here:

https://creativecommons.org/publicdomain/zero/1.0/deed

Full text of the license can be found in LICENSE.en.txt file, as well as here:

https://creativecommons.org/publicdomain/zero/1.0/legalcode
